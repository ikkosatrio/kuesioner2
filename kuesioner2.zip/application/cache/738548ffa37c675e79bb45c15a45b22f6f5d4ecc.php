<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">

					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="index.html"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active">Dashboard</li>
						</ul>
					</div>
				</div>
				<!-- /page header -->


				<!-- Content area -->
				<div class="content">

					<!-- Quick stats boxes -->
							<div class="row">
								<div class="col-lg-4">

									<!-- Members online -->
									<div class="panel bg-teal-400">
										<div class="panel-body">
											

											<h3 class="no-margin"><?php echo e($nkuesioner); ?></h3>
											Jumlah Kuesioner
											<div class="text-muted text-size-small">Jumlah kuesioner yang dimiliki</div>
										</div>

										<div class="container-fluid">
											<div id="members-online"></div>
										</div>
									</div>
									<!-- /members online -->

								</div>

								<div class="col-lg-4">

									<!-- Current server load -->
									<div class="panel bg-pink-400">
										<div class="panel-body">
											

											<h3 class="no-margin"><?php echo e($nresponden); ?></h3>
											Jumlah Responden
											<div class="text-muted text-size-small">Jumlah responden yang telah terdaftar</div>
										</div>

										<div id="server-load"></div>
									</div>
									<!-- /current server load -->

								</div>

								<div class="col-lg-4">

									<!-- Today's revenue -->
									<div class="panel bg-blue-400">
										<div class="panel-body">
											<h3 class="no-margin"><?php echo e($nsoal); ?></h3>
											Jumlah Soal
											<div class="text-muted text-size-small">Jumlah seluruh soal</div>
										</div>

										<div id="today-revenue"></div>
									</div>
									<!-- /today's revenue -->

								</div>
							</div>
							<!-- /quick stats boxes -->


				</div>
				<!-- /content area -->

			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
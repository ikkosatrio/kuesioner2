<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<!-- Global stylesheets -->
	<link rel="shortcut icon" type="image/png" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>"/>
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/core.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/components.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/colors.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/js/sweetalert.min.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/custom2.css" rel="stylesheet" type="text/css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" rel="stylesheet" type="text/css">
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/libraries/jquery.min.js"></script>
	<!-- /global stylesheets -->
	<?php echo $__env->yieldContent('style'); ?>
	<!-- Core JS files -->


</head>

<body>

	<!-- Main navbar -->
	<div class="navbar navbar-inverse">
		<div class="navbar-header">
			

			
		</div>

		
			<ul class="nav navbar-nav">
				<li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>
				
			</ul>

			

			<ul class="nav navbar-nav navbar-right">

				
				<?php if($ctrl->session->userdata('IsLogin')): ?>


				<li class="dropdown dropdown-user">
					<a class="dropdown-toggle" data-toggle="dropdown">
						<img src="<?php echo e(img_holder('profile')); ?>" alt="">
						<span><?php echo e($ctrl->session->userdata('auth_name')); ?></span>
						<i class="caret"></i>
					</a>

					<ul class="dropdown-menu dropdown-menu-right">
						
						<li><a href="#"><i class="icon-user"></i><?php echo e($ctrl->session->userdata('nama')); ?></a></li>
						<li><a href="<?php echo e(base_url('main/logout')); ?>"><i class="icon-switch2"></i> Logout</a></li>
					</ul>
				</li>
				<?php endif; ?>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->


	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">

			<!-- Main sidebar -->

			<!-- /main sidebar -->


			<!-- Main content -->
			<?php echo $__env->yieldContent('content'); ?>

			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/notifications/jgrowl.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/visualization/d3/d3.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/visualization/d3/d3_tooltip.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/styling/switchery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/styling/uniform.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/bootstrap_multiselect.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/ui/moment/moment.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/pickers/daterangepicker.js"></script>


	<?php echo $__env->yieldContent('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/corejs-typeahead/1.2.1/bloodhound.min.js"></script>
	<!-- /theme JS files -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/cak-js.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/sweetalert.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/chart/Chart.min.js"></script>

	<?php echo $__env->yieldContent('script'); ?>


	<script type="text/javascript">
		function deleteIt(that){
		swal({
			title: "Apa Anda Yakin ?",
			text: "Anda Akan Menghapus Data Ini",
			type: "warning",
			showCancelButton: true,
			confirmButtonColor: "#DD6B55",
			confirmButtonText: "Ya, Hapus Data!",
			closeOnConfirm: false
		}, function(){
			swal({
					title: "Deleted",
					text: "Data Anda Telah Di Hapus",
					type: "success"
			},function(){
				redirect($(that).attr('data-url'));
			});

		});
	}
	</script>
</body>
</html>

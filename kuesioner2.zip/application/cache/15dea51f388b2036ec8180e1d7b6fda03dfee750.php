<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/tables/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/datatables_basic.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="<?php echo e(base_url('superuser')); ?>"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active"><a href="#">Kuesioner</a></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->


				<!-- Content area -->
				<div class="content">

					<!-- Basic datatable -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Daftar Kuesioner</h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                		<li><a data-action="reload"></a></li>
			                		<li><a data-action="close"></a></li>
			                	</ul>
		                	</div>
						</div>
						<div class="panel-heading">
							
							<a href="<?php echo e(base_url('superuser/kuesioner/create')); ?>"><button type="button" class="btn bg-teal-400 btn-labeled"><b><i class="icon-plus-circle2"></i></b> Tambah Kuesioner</button></a>
						</div>
						<table class="table table-striped datatable-basic table-lg table-responsive">
		                    <thead>
		                        <tr>
		                        	<th>No</th>
		                        	<th>Kode</th>
		                            <th>Judul</th>
		                            <th>Total Soal</th>
		                            <th>Jumlah Responden Menjawab</th>
		                            <th class="text-center">Aksi</th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    	<?php $__currentLoopData = $kuesioner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                         <tr>
		                        	<td align="center"><?php echo e(($key+1)); ?></td>
			                        <td align="left">
			                        	<a href="<?php echo e(base_url('superuser/kuesioner/update/'.$result->id_kuesioner.'/'.seo($result->judul))); ?>">
			                        	<?php echo e($result->kode_kuesioner); ?>

			                        	</a><br>			                  
			                        </td>
			                        <td class="" style="width: 300px">
			                        	<span class="text-size-small text-muted">
			                        		<?php echo e($result->judul); ?> (<?php echo e($result->skala); ?>)
			                        	</span>
			                        </td>
			                        <td class="text-center">
			                        	<span class="text-size-small text-muted">
			                        		<?php echo e(countSoal($result)); ?>

			                        	</span>
			                        </td>
			                        <td class="text-center">
			                        	<span class="text-size-small text-muted">
			                        		<a href="<?php echo e(base_url('superuser/kuesioner/listjawaban/'.$result->id_kuesioner)); ?>">
				                        		<?php echo e(countJawaban($result)); ?>

				                        	</a>
			                        	</span>
			                        </td>
			                        <td class="text-center">
			                           <div class="btn-group">
					                    	<button type="button" class="btn btn-danger btn-sm btn-rounded dropdown-toggle" data-toggle="dropdown"><i class="icon-cog5 position-left"></i> Action <span class="caret"></span></button>
					                    	<ul class="dropdown-menu dropdown-menu-right">
												<li>
													<a href="<?php echo e(base_url('superuser/kuesioner/jawab/'.$result->id_kuesioner)); ?>">
														<i class="fa fa-edit"></i> Jawab Kuesioner
													</a>
												</li>
												<li>
													<a href="<?php echo e(base_url('superuser/kuesioner/update/'.$result->id_kuesioner)); ?>">
														<i class="fa fa-edit"></i> Ubah Kuesioner
													</a>
												</li>
												<li><a href="javascript:void(0)" onclick="deleteIt(this)" 
												data-url="<?php echo e(base_url('superuser/kuesioner/deleted/'.$result->id_kuesioner)); ?>">
														<i class="fa fa-trash"></i> Hapus Kuesioner
													</a>
												</li>
											</ul>
										</div>
			                        </td>
		                        </tr>
		                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    </tbody>
		                </table>
					</div>
					<!-- /basic datatable -->					

				</div>
				<!-- /content area -->

			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
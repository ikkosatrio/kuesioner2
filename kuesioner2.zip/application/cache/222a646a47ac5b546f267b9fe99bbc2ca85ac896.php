<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/tables/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/datatables_basic.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="<?php echo e(base_url('superuser')); ?>"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active"><a href="#">Kuesioner</a></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->


				<!-- Content area -->
				<div class="content">
					<!-- Basic datatable -->
					<div class="panel panel-flat">
						<div class="panel-heading">
							<h5 class="panel-title">Jawaban dari : <?php echo e($kuesioner->judul); ?></h5>
							<h5>Average <?php echo e($total); ?></h5>
							<div class="heading-elements">
								<ul class="icons-list">
			                		<li><a data-action="collapse"></a></li>
			                		<li><a data-action="reload"></a></li>
			                		<li><a data-action="close"></a></li>
			                	</ul>
		                	</div>
						</div>
						<table class="table table-striped datatable-basic table-lg table-responsive">
		                    <thead class="bg-teal-400">
		                        <tr>
		                        	<th>No</th>
		                        	<th>Responden</th>
		                        	<th>Hasil</th>
		                            <th class="pull-right">Aksi</th>
		                        </tr>
		                    </thead>
		                    <tbody>
		                    	<?php $__currentLoopData = $jawaban; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                         <tr>
			                        	<td align="center"><?php echo e($key+1); ?></td>
				                        <td class="">
				                        	<span class="text-size-small text-muted">
				                        		<?php echo e($result->nim); ?> - <?php echo e($result->nama); ?>

				                        	</span>
				                        </td>
				                        <td align="center"><?php echo e($result->hasil); ?></td>
				                        <td align="center">DETAIL</td>
			                        </tr>
			                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                    </tbody>
		                </table>
		                <br>
		                <br>
		            
						<br>
					</div>
					</form>
					<!-- /basic datatable -->					

				</div>
				<!-- /content area -->

			</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('title'); ?>
Dashboard - Administrasi
<?php $__env->stopSection(); ?>
<?php $__env->startSection('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/tables/datatables/datatables.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/pages/datatables_basic.js"></script>

    
    <script src="<?php echo e(base_url()); ?>assets/getorgchart/getorgchart.js"></script>
    <link href="<?php echo e(base_url()); ?>assets/getorgchart/getorgchart.css" rel="stylesheet" />


    <script type="text/javascript">
        $.getJSON("http://localhost/kuesioner2/superuser/getJsonStrukturLoad", function (source) {
            var peopleElement = document.getElementById("people");
            var orgChart = new getOrgChart(peopleElement, {
                // theme: "helen",
                primaryFields: ["Name", "Title"],
                photoFields: ["Image"],
                linkType: "M",
                enableEdit: false,
                enableDetailsView: true,
                dataSource: source
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <style type="text/css">
        html, body {
            margin: 0px;
            padding: 0px;
            width: 100%;
            height: 100%;
            overflow: hidden;
        }

        #people {
            width: 100%;
            height: 100%;
        }
    </style>

	<div class="content-wrapper">

				<!-- Page header -->
				<div class="page-header page-header-default">
					<div class="breadcrumb-line">
						<ul class="breadcrumb">
							<li><a href="<?php echo e(base_url('superuser')); ?>"><i class="icon-home2 position-left"></i> Home</a></li>
							<li class="active"><a href="#">Struktur</a></li>
						</ul>
					</div>
				</div>
				<!-- /page header -->


				<!-- Content area -->
				<div class="content">

					<!-- Basic datatable -->
					<div class="panel panel-flat">
						
							
							
								
			                		
			                		
			                		
			                	
		                	
						
						
							
						
						<div id="people"></div>
					</div>
					<!-- /basic datatable -->					

				</div>
				<!-- /content area -->

			</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
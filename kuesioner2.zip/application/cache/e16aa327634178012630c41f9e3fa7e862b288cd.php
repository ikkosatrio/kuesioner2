<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php echo $__env->yieldContent('title'); ?></title>

	<!-- Global stylesheets -->
	<link rel="shortcut icon" type="image/png" href="<?php echo e(base_url()); ?>assets/images/website/config/icon/<?php echo e($config->icon); ?>"/>
	<link href="https://fonts.googleapis.com/css?family=Roboto:400,300,100,500,700,900" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/icons/icomoon/styles.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/core.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/components.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/colors.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/js/sweetalert.min.css" rel="stylesheet" type="text/css">
	<link href="<?php echo e(base_url()); ?>assets/css/custom2.css" rel="stylesheet" type="text/css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.css" rel="stylesheet" type="text/css">
	
	<!-- /global stylesheets -->
	<?php echo $__env->yieldContent('style'); ?>
	<!-- Core JS files -->
	

</head>

<body>

	<!-- Main navbar -->
	<div class="navbar navbar-inverse">
		<div class="navbar-header">
			<a class="navbar-brand" href="<?php echo e(base_url('superuser')); ?>"><img src="<?php echo e(base_url()); ?>assets/images/website/config/logo/<?php echo e($config->logo); ?>" alt=""></a>
			
			<ul class="nav navbar-nav visible-xs-block">
				<li><a data-toggle="collapse" data-target="#navbar-mobile"><i class="icon-tree5"></i></a></li>
				<li><a class="sidebar-mobile-main-toggle"><i class="icon-paragraph-justify3"></i></a></li>
			</ul>
		</div>

		<div class="navbar-collapse collapse" id="navbar-mobile">
			<ul class="nav navbar-nav">
				<li><a class="sidebar-control sidebar-main-toggle hidden-xs"><i class="icon-paragraph-justify3"></i></a></li>
				
			</ul>

			

			<ul class="nav navbar-nav navbar-right">

				

				<li class="dropdown dropdown-user">
					<a class="dropdown-toggle" data-toggle="dropdown">
						<img src="<?php echo e(img_holder('profile')); ?>" alt="">
						<span><?php echo e($ctrl->session->userdata('auth_name')); ?></span>
						<i class="caret"></i>
					</a>

					<ul class="dropdown-menu dropdown-menu-right">
						
						
						<li><a href="<?php echo e(base_url('authentication/logout')); ?>"><i class="icon-switch2"></i> Logout</a></li>
					</ul>
				</li>
			</ul>
		</div>
	</div>
	<!-- /main navbar -->


	<!-- Page container -->
	<div class="page-container">

		<!-- Page content -->
		<div class="page-content">

			<!-- Main sidebar -->
			<div class="sidebar sidebar-main">
				<div class="sidebar-content">

					<!-- User menu -->
					<div class="sidebar-user">
						<div class="category-content">
							<div class="media">
								<a href="#" class="media-left"><img src="<?php echo e(img_holder('profile')); ?>" class="img-circle img-sm" alt=""></a>
								<div class="media-body">
									<span class="media-heading text-semibold">Admin<?php echo e(ucwords($ctrl->session->userdata('authmember_role'))); ?></span>
									<div class="text-size-mini text-muted">
										<i class="icon-pin text-size-small"></i> <?php echo e($ctrl->session->userdata('auth_name')); ?>

									</div>
								</div>

								<div class="media-right media-middle">
									<ul class="icons-list">
										<li>
											<a href="#"><i class="icon-cog3"></i></a>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<!-- /user menu -->


					<!-- Main navigation -->
					<div class="sidebar-category sidebar-category-visible">
						<div class="category-content no-padding">
							<ul class="navigation navigation-main navigation-accordion">

								<!-- Main -->
								<li class="navigation-header"><span>Main</span> <i class="icon-menu" title="Main pages"></i></li>
								<li class="<?php echo e(match($menu,'dashboard','active')); ?>"><a href="<?php echo e(base_url('superuser')); ?>"><i class="icon-home4"></i> <span>Dashboard</span></a></li>
								
									<li class="<?php echo e(match($menu,'config','active')); ?>"><a href="<?php echo e(base_url('superuser/config')); ?>"><i class="icon-gear"></i> <span>Configurasi Website</span></a></li>
									<li class="<?php echo e(match($menu,'responden','active')); ?>"><a href="<?php echo e(base_url('superuser/responden')); ?>"><i class="icon-users"></i> <span>Responden</span></a></li>
									<li class="<?php echo e(match($menu,'kuesioner','active')); ?>"><a href="<?php echo e(base_url('superuser/kuesioner')); ?>"><i class="icon-clipboard"></i> <span>Kuesioner</span></a></li>
									<li class="<?php echo e(match($menu,'hasil','active')); ?>"><a href="<?php echo e(base_url('superuser/hasil')); ?>"><i class="icon-stats-bars"></i> <span>Hasil</span></a></li>
							</ul>
						</div>
					</div>
					<!-- /main navigation -->

				</div>
			</div>
			<!-- /main sidebar -->


			<!-- Main content -->
			<?php echo $__env->yieldContent('content'); ?>
			
			<!-- /main content -->

		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->

	<!-- Theme JS files -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/visualization/d3/d3.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/visualization/d3/d3_tooltip.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/styling/switchery.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/styling/uniform.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/forms/selects/bootstrap_multiselect.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/ui/moment/moment.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/plugins/pickers/daterangepicker.js"></script>

	
	<?php echo $__env->yieldContent('corejs'); ?>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/core/app.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-3-typeahead/4.0.2/bootstrap3-typeahead.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.12.1/jquery-ui.js"></script>    
	
	<script src="https://cdnjs.cloudflare.com/ajax/libs/corejs-typeahead/1.2.1/bloodhound.min.js"></script>  
	<!-- /theme JS files -->
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/cak-js.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/js/sweetalert.min.js"></script>
	<script type="text/javascript" src="<?php echo e(base_url()); ?>assets/chart/Chart.min.js"></script>
	
	<?php echo $__env->yieldContent('script'); ?>
	

	<script type="text/javascript">
		function deleteIt(that){
		swal({   
			title: "Apa Anda Yakin ?",   
			text: "Anda Akan Menghapus Data Ini",   
			type: "warning",   
			showCancelButton: true,   
			confirmButtonColor: "#DD6B55",   
			confirmButtonText: "Ya, Hapus Data!",   
			closeOnConfirm: false 
		}, function(){   
			swal({   
					title: "Deleted",   
					text: "Data Anda Telah Di Hapus",   
					type: "success"
			},function(){
				redirect($(that).attr('data-url'));
			}); 
			
		});	
	}
	</script>
</body>
</html>
